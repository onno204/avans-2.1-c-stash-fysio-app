﻿namespace Core.Domain
{
    public enum UserType
    {
        Therapist,
        StudentTherapist,
        Student,
        Employee
    }
}
