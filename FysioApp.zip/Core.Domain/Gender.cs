﻿namespace Core.Domain
{
    public enum Gender
    {
        Male,
        Female,
        Other
    }
}
