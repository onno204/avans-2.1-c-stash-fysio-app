﻿namespace Core.Domain
{
    public enum TreatmentRoom
    {
        ExerciseRoom,
        TreatmentRoom
    }
}
